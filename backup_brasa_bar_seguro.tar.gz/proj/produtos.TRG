TYPE=TRIGGERS
triggers='CREATE DEFINER=`root`@`localhost` TRIGGER `trg_estoque_positivo` BEFORE UPDATE ON `produtos` FOR EACH ROW SET NEW.estoque = GREATEST(NEW.estoque, 0)'
sql_modes=524288
definers='root@localhost'
client_cs_names='utf8mb4'
connection_cl_names='utf8mb4_general_ci'
db_cl_names='utf8mb4_general_ci'
created=1793237280823907
