TYPE=VIEW
query=select `p`.`id_produto` AS `id_produto`,`p`.`nome_produto` AS `nome_produto`,`p`.`preco` AS `preco`,`p`.`estoque` AS `estoque`,`p`.`imagem` AS `imagem`,`p`.`id_categoria` AS `id_categoria`,`c`.`nome_categoria` AS `nome_categoria` from (`proj`.`produtos` `p` join `proj`.`categorias` `c` on(`p`.`id_categoria` = `c`.`id_categoria`))
md5=d01c09f541c255600e986403213d918e
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=1
with_check_option=0
timestamp=0001793237280939740
create-version=2
source=SELECT `p`.`id_produto` AS `id_produto`, `p`.`nome_produto` AS `nome_produto`, `p`.`preco` AS `preco`, `p`.`estoque` AS `estoque`, `p`.`imagem` AS `imagem`, `p`.`id_categoria` AS `id_categoria`, `c`.`nome_categoria` AS `nome_categoria` FROM (`produtos` `p` join `categorias` `c` on(`p`.`id_categoria` = `c`.`id_categoria`))
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `p`.`id_produto` AS `id_produto`,`p`.`nome_produto` AS `nome_produto`,`p`.`preco` AS `preco`,`p`.`estoque` AS `estoque`,`p`.`imagem` AS `imagem`,`p`.`id_categoria` AS `id_categoria`,`c`.`nome_categoria` AS `nome_categoria` from (`proj`.`produtos` `p` join `proj`.`categorias` `c` on(`p`.`id_categoria` = `c`.`id_categoria`))
mariadb-version=101119
